<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('website_general.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>


</head>
<body class="website-body text-body">
    <div id="app">
        <?php echo $__env->make('website.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Content -->
        <main class="container-fluid p-0">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('website.partials.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH /var/www/html/laravel-app/resources/views/website/partials/frontend-main.blade.php ENDPATH**/ ?>